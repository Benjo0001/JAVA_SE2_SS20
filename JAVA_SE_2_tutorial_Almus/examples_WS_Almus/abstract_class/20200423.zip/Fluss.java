
/*
Flüsse haben zusätzlich (zu einem Gewässer) eine Länge. 
Weiterhin mündet jeder Fluss in genau ein Gewässer. 
Durch diese Mündungsbeziehung erreicht man von einem Fluss aus (evtl. über andere Flüsse) irgendwann ein Meer. 
Für Flüsse sollten eine Methode vorgesehen werden, um dieses Gewässer zu ermitteln.
*/
public class Fluss extends Gewaesser
{
    private long laenge;
    private Gewaesser muendetIn;
    
    public void setLaenge(long laenge)
    {
        if(laenge<=0) {
            System.out.println("Fehler: Der fuer die Laenge uebergebene Wert ist kleiner 0. Bitte geben Sie einen Wert groesser oder gleich 0 ein.");
        }
        else {
            this.laenge=laenge;
        }
    }

    public long getLaenge()
    {
        return this.laenge;
    }

    // Achtung: Ergibt dieser Konstruktur Sinn? (Und wenn ja, was fehlt hier?)
    //this.setSchiffbarkeit(true);
    public Fluss()
    {
        
    }

    public Fluss(String name, boolean schiffbarkeit, int stoffbelastung, long laenge, Gewaesser muendetIn)
    {
        super(name, schiffbarkeit, stoffbelastung);  
        
        this.setLaenge(laenge);
        this.setMuendetIn(muendetIn);
    }

    public void setMuendetIn(Gewaesser muendetIn)
    {
        // Kann in einen Fluss muenden -- nur dann problematisch, wenn Fluss in sich selbst muendet!
        // Kann in ein Meer muenden
        if (muendetIn == this)
        {
            System.out.println("Fehler: Der Fluss darf nicht in sich selbst muenden! Bitte korrigieren Sie diese Angabe!");
        }
        else
        {
            this.muendetIn = muendetIn;
        }
    }

    public Gewaesser muendetIn()
    {
        return this.muendetIn;
    }

    public void printChainToOcean()
    {
        // Berounka (nicht schiffbar) --> Moldau --> Elbe --> Nordsee
        // Solange der Fluss in ein Gewaesser mundet, das kein Meer ist, springe ein Gewaesser weiter
        // Welcher Schleifentyp?
        
        // Erstellen einer Variablen, die im ersten Moment auf das Startobjekt zeigt (diese Instanz, in der wir uns befinden)
        Gewaesser next = this;
        
        // Laufe solange durch die Schleife, bis diese Variable null ist
        while (next != null)
        {
            // Alternative Schreibweise
            // String toPrint = next.getName() + " " + (next.getSchiffbarkeit() == false ? "(nicht schiffbar) " : "") + (next.muendetIn() != null ? "--> " : "");
            // System.out.print(toPrint);
            // next = next.muendetIn();

            // Gebe den Namen des aktuellen Gewaessers aus
            System.out.print(next.getName());
            
            // Wenn es nicht schuiffbar ist, fuege einen Hinweis darauf hinzu
            if (next.getSchiffbarkeit() == false) {
                System.out.print(" (nicht schiffbar)");
            }

            // Setze die Variable next auf das Gewaesser, in das next muendet.
            next = next.muendetIn();
            
            // Wenn der Nachfolger nicht leer ist, dann fuege den Pfeil ein
            if (next != null)
            {
                System.out.print(" --> ");
            }
        }

        // Den hier hatten wir noch vergessen:
        System.out.println();
    }
}