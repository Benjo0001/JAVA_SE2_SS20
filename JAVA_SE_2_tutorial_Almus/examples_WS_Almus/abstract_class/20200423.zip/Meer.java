
public class Meer extends Gewaesser {
    private double flaeche;

    /**
     * @return the flaeche
     */
    public double getFlaeche() {
        return flaeche;
    }

    /**
     * @param flaeche the flaeche to set
     */
    public void setFlaeche(double flaeche) {
        if (flaeche <= 0)
        {
            System.out.println("Fehler: Der fuer die Flaeche uebergebene Wert ist kleiner oder gleich 0. Bitte geben Sie einen Wert ein, der groesser 0 ist.");
            return;
        }

        this.flaeche = flaeche;
    }

    // Ist dieser Konstruktor sinnvoll?
    public Meer() {
        this("StandardMeer", 0, 500);
    }

    public Meer(String name, int stoffbelastung, double flaeche)
    {
        super(name, true, stoffbelastung);

        this.setFlaeche(flaeche);
    }

    public Gewaesser muendetIn() {
        return null;
    }
}