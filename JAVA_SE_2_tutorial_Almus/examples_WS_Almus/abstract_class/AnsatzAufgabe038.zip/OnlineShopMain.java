
public class OnlineShopMain {
    public static void main(String[] args) {
        
        // Instanciate a book as article
        Article artikel1 = new Book("Mein zweites Buch", "Auch ich", 2020, 19.99, "B000009");
        
        // Instanciate a book as book
        Book book1 = new Book("Mein Buch", "Ich", 2020, 9.99, "B000010");

        // Print the name representation of both instances
        System.out.println(book1.getName());
        System.out.println(artikel1.getName());
    }
}