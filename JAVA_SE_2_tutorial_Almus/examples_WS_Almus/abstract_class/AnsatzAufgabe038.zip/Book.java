
public class Book extends Article {
    // Bücher haben zusätzlich zu den Artikelinformationen noch einen Buchtitel, einen Autorennamen und ein Erscheinungsjahr.
    private String title;
    private String authorName;
    private int publishingYear;

    /**
     * @return the authorName
     */
    public String getAuthorName() { return authorName; }

    /**
     * @return the publishingYear
     */
    public int getPublishingYear() { return publishingYear; }

    /**
     * @return the title
     */
    public String getTitle() { return title; }

    // Constructors
    // For the next Session: Dies this constructor make any sense?
    public Book() {
        this("My Book", "My Author (Me)", 2020, 19.99, "B000001");
    }

    public Book(String title, String authorName, int publishingYear, double netPrice, String articleNumber) {
        super(articleNumber, netPrice);

        // Validate title, authorName & publishingYear
        if (title.length() == 0) {
            this.title = "Default Book Title";
            System.out.println("The title you entered is empty. Defaulting to 'Default Book Title'!");
        }
        else {
            this.title = title;
        }

        if (authorName.length() == 0) {
            this.authorName = "Default Author Name";
            System.out.println("The author name you entered is empty. Defaulting to 'Default Author Name'!");
        }
        else {
            this.authorName = authorName;
        }

        if (publishingYear < 0) {
            this.publishingYear = 0;
            System.out.println("You entered a negative value for publishing year. Defaulting to 0!");
        }
        else {
            this.publishingYear = publishingYear;
        }
    }

    public String getName() {
        // For the next session: Can we optimize this?
        // <Artikelnummer (immer 7 stellig!)> : <Artikeltyp> - <Titel> -> <Nettopreis>
        return this.getArticleNumber() + " : " + "Book" + " - " + this.getTitle() + " -> " + this.getNetPrice();
    }

    public double getGrossPrice() {
        // For the next session: Can we optimize this?
        // Nettopreis + Nettopreis * Mehrwertsteuersatz
        return this.getNetPrice() + this.getNetPrice() * 1.07;
    }
}