
public abstract class Article {
    // Jeder Artikel besitzt eine bis zu siebenstellige Artikelnummer und einen Nettopreis.
    // Jeder Artikel hat einen konstanten Mehrwertsteuersatz, der sich jedoch in der Höhe für jede Artikelart unterscheidet.
    // Bücher haben einen Mehrwertsteuersatz von 7%
    // DVDs haben einen Mehrwertsteuersatz von 19%
    // CDs haben einen Mehrwertsteuersatz von 17%
    // Es muss für jeden Artikel möglich sein, den Nettopreis abzurufen.
    // Es muss für jeden Artikel möglich sein, den Bruttopreis abzurufen.
    private String articleNumber;
    private double netPrice;

    /**
     * @return the articleNumber
     */
    public String getArticleNumber() {
        return articleNumber;
    }

    /**
     * @return the netPrice
     */
    public double getNetPrice() {
        return netPrice;
    }

    // Constructors
    // For the next session: Does this constructor make any sense?
    public Article() {
        this("0000001", 1);
    }

    public Article(String articleNumber, double netPrice) {
        // Validate input values
        // net price
        if (netPrice < 0)
        {
            this.netPrice = 0;
            System.out.println("You entered a negative net price, defaulting to 0 as net price!");
        }
        else
        {
            this.netPrice = netPrice;
        }

        // articleNumber
        if (articleNumber.length() != 7)
        {
            this.articleNumber = "1000000";
            System.out.println("You entered a article number which is not seven chars long. Defaulting to 1000000!");
        }
        else
        {
            this.articleNumber = articleNumber;
        }
    }

    public abstract double getGrossPrice();

    public abstract String getName();
}