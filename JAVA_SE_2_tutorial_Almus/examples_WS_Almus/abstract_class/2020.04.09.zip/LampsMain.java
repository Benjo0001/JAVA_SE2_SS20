public class LampsMain {
    public static void main(String[] args) {
        // A bulb consumes 219 KWh per year when on for 10 hours per day.
        // A led bulb consumes 32 KWh per year when on for 10 hours per day.
        
        // Following line does not work, because lamp is abstract.
        //Lamp myLamp = new Lamp(60);
        Lamp bulb = new Bulb(60);
        Lamp led = new LedBulb(9);

        System.out.println(bulb.annualConsumptionAsReadableString(10));
        System.out.println(led.annualConsumptionAsReadableString(10));
    }
}