public class Bulb extends Lamp {
    public Bulb(int watt) {
        super(watt);
    }

    public String annualConsumptionAsReadableString(int hoursPerDay) {
        return "A bulb consumes " + this.annualPowerConsumption(hoursPerDay) + " KWh per year when on for " + hoursPerDay + " hours per day.";
    }
}