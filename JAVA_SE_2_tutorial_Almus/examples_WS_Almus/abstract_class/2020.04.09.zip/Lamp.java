public abstract class Lamp {
    private int watt;

    /**
     * @return the watt
     */
    public int getWatt() {
        return this.watt;
    }

    public Lamp(int watt) {
        
        // Validation
        if (watt <= 0)
        {
            System.out.println("You entered a negative number for watt. Defaulting to 10.");
            this.watt = 10;
        }
        else
        {
            this.watt = watt;
        }
    }

    public int annualPowerConsumption(int hoursPerDay) {
        // (Leistung [Watt] * Betriebsstunden pro Tag * 365) / 1000
        // Calculation missing!!
        return (this.watt * hoursPerDay * 365) / 1000;
    }

    public abstract String annualConsumptionAsReadableString(int hoursPerDay);
}