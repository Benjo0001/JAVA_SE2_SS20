/*
Wir wollen Klassen zur Repräsentation von Gewässern, Flüssen und Meeren schreiben. Dabei sollten wir folgendes beachten:

Jedes Gewässer hat einen Namen sowie Angaben zur Schiffbarkeit (ja/nein) und zur Schadstoffbelastung (reelle Zahl).
Meere verfügen zusätzlich (zu einem Gewässer) über eine Fläche und sind immer schiffbar.
Flüsse haben zusätzlich (zu einem Gewässer) eine Länge. 
Weiterhin mündet jeder Fluss in genau ein Gewässer. 
Durch diese Mündungsbeziehung erreicht man von einem Fluss aus (evtl. über andere Flüsse) irgendwann ein Meer. 
Für Flüsse sollten eine Methode vorgesehen werden, um dieses Gewässer zu ermitteln.

Schreiben Sie Klassen zur Repräsentation von Gewässern, Flüssen und Meeren, 
wobei zu jeder Klasse die notwendigen Variablen, ein Konstruktor und für Flüsse die verlangte Methode anzugeben sind. 
Benutzen Sie dabei auf sinnvolle Art abstrakte Klassen und Vererbung.
Schreiben Sie ein Testprogramm, um die angegebenen Testfälle nachzustellen.

Testfälle
Berounka (nicht schiffbar) --> Moldau --> Elbe --> Nordsee
Havel --> Elbe --> Nordsee

Hilfen
Welche Relationen könnten zwischen den verschiedenen Klassen bestehen und gibt es vielleicht eine Oberklasse?
Eventuell ist es sinnvoll, die Relationen vorher in einem Diagramm darzustellen, um eine bessere Übersicht zu bekommen.
Zur Meerbestimmung könnten Sie in einer Schleife Schritt für Schritt die Flüsse herabgehen, bis Sie im Meer enden. 
Ein Meer ist daran zu erkennen, dass es in keinem Fluss endet, also eine entsprechende selbstgeschriebene Getter-Methode denWert null liefert. 
Um den Namen des Gewässers zu ermitteln, benötigt man natürlich eine entsprechende Getter- oder toString()-Methode.

*/
public class Aufgabe039Main {

    public static void main(String[] args) {
        Gewaesser gewaesserA = new Meer("A", 123, 200);
        Meer gewaesserB = new Meer("B", 123, 100.5);
    }
}