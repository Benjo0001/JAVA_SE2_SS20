public abstract class Gewaesser {
    private String name;
    private boolean schiffbarkeit;
    private int stoffbelastung;

    public String getName()
    {
        return this.name;
    }

    public boolean getSchiffbarkeit()
    {
        return this.schiffbarkeit;
    }

    public int getStoffbelastung()
    {
        return this.stoffbelastung;
    }

    public void setName(String name)
    {
        if (name == null)
        {
            System.out.println("Fehler: Der fuer den Namen uebergebene Wert ist 'null'. Bitte geben Sie einen Namen ein, der nicht 'null' ist.");
            return;
        }

        if(name.length()==0) {
            System.out.println("Fehler: Der fuer den Namen uebergebene Wert ist leer. Bitte geben Sie einen Namen ein, der nicht leer ist.");
            return;
        }

        this.name=name;
    }

    public void setSchiffbarkeit(boolean schiffbarkeit)
    {
        if (schiffbarkeit)
        {
            System.out.println("DEBUG: Neuer Wert Schiffbarkeit: schiffbar");
        }
        else
        {
            System.out.println("DEBUG: Neuer Wert Schiffbarkeit: nicht schiffbar");
        }

        this.schiffbarkeit=schiffbarkeit;
    }

    public void setStoffbelasstung(int stoffbelastung)
    {
        if(stoffbelastung<0) {
            System.out.println("Fehler: Der fuer die Schadstoffbelastung uebergebene Wert ist kleiner 0. Bitte geben Sie einen Wert groesser oder gleich 0 ein.");
        }
        else {
            this.stoffbelastung=stoffbelastung;
        }
    }

    public Gewaesser()
    {
        this("sanaga", true, 123);
        
        // this.setName(null);
        // this.setStoffbelasstung(123);
        // this.setSchiffbarkeit(true);
    } 

    public Gewaesser(String name , boolean schiffbarkeit,int stoffbelastung)
    {
        this.setName(name);
        this.setStoffbelasstung(stoffbelastung);
        this.setSchiffbarkeit(schiffbarkeit);
    }

    public abstract void Muendung();
}
    