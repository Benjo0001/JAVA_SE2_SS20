public class RechteckListDemo {
    public static void main(String[] args) {
        RechteckList myRechteckList = new RechteckList();

        Rechteck re1 = new Rechteck(10, 10);
        Rechteck re2 = re1;
        Rechteck re3 = new Rechteck(20, 20);
        Rechteck re4 = new Rechteck(10, 10);

        System.out.println("re1 == re2? --> " + re1.equals(re2));
        System.out.println("re1 == re3? --> " + re1.equals(re3));
        System.out.println("re1 == re4? --> " + re1.equals(re4));

        myRechteckList.addRechteck(re1);
        myRechteckList.addRechteck(re2);
        myRechteckList.addRechteck(re3);
        myRechteckList.addRechteck(re4);

        System.out.println("Elemente in der Liste: " + myRechteckList.getNumberOfElementsInList());

        myRechteckList.printMyListItems();

        myRechteckList.removeRechteck(re1);

        System.out.println("Elemente in der Liste: " + myRechteckList.getNumberOfElementsInList());

        myRechteckList.removeRechteck(re1);

        System.out.println("Elemente in der Liste: " + myRechteckList.getNumberOfElementsInList());

        myRechteckList.removeRechteck(re1);

        System.out.println("Elemente in der Liste: " + myRechteckList.getNumberOfElementsInList());
    }
}