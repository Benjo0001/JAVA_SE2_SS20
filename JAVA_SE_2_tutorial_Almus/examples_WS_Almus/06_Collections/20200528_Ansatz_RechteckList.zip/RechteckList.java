import java.util.LinkedList;

public class RechteckList {
    private LinkedList<Rechteck> rechteckList;

    public RechteckList() {
        this.rechteckList = new LinkedList<>();
    }

    public int getNumberOfElementsInList()
    {
        return this.rechteckList.size();
    }

    public boolean addRechteck(Rechteck item) {
        // Validieren des Parameters fehlt!
        return this.rechteckList.add(item);
    }

    public boolean removeRechteck(Rechteck item) {
        // Validieren des Parameters fehlt!
        return this.rechteckList.remove(item);
    }

    public void printMyListItems() {
        System.out.println("Elemente in der Liste:");
        
        // Hier mit einem ListIterator anstelle der Foreach-Schleife arbeiten für die Übungsaufgabe :)
        for (Rechteck rechteck : rechteckList) {
            System.out.println("Das Rechteck hat die Laenge (" + rechteck.getLength() + ") und die Breite (" + rechteck.getWidth() + ");");
        }
    }
}