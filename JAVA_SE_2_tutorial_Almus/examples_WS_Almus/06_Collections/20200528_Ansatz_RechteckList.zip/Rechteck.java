public class Rechteck {
    private int length;
    private int width;

    public Rechteck(int width, int length) {
        this.length = length;
        this.width = width;
    }

    public int getLength() {
        return length;
    }

    public int getWidth() {
        return width;
    }
}