import java.util.*;

public class ArrayListDemo {

    public static void main(String[] args) {
        MyArrayListDemoClass listClass = new MyArrayListDemoClass();
        
        // Integer int1 = Integer.valueOf(10);
        // Integer int2 = int1;
        // Integer int3 = Integer.valueOf(20);
        // Integer int4 = Integer.valueOf(10);

        // System.out.println("int1 == int2? --> " + int1.equals(int2));
        // System.out.println("int1 == int3? --> " + int1.equals(int3));
        // System.out.println("int1 == int4? --> " + int1.equals(int4));

        listClass.addItemToMyList(10);
        listClass.addItemToMyList(20);
        listClass.addItemToMyList(30);
        listClass.addItemToMyList(40);
        listClass.addItemToMyList(50);
        listClass.addItemToMyList(60);

        listClass.printMyListItems();

        // // Frage: Was passiert hier?
        // listClass.addItemToMyList(null);
        
        listClass.addItemToMyList(70);

        if (listClass.removeItemFromMyList(40))
        {
            System.out.println("Element wurde geloescht!");
        }
        else
        {
            System.out.println("Element wurde nicht gefunden oder es ist ein Fehler aufgetreten.");
        }

        if (listClass.removeItemFromMyList(90))
        {
            System.out.println("Element wurde geloescht!");
        }
        else
        {
            System.out.println("Element wurde nicht gefunden oder es ist ein Fehler aufgetreten.");
        }

        listClass.printMyListItems();

        System.out.println("Ende des Programms erreicht.");
    }
}