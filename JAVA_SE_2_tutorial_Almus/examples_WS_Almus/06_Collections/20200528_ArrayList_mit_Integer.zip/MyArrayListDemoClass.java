import java.util.*;

public class MyArrayListDemoClass {
    private ArrayList<Integer> myList;

    public MyArrayListDemoClass() {
        // Wenn Größe bekannt, dann Konstruktor mit parameter für initiale Größe verwenden.
        this.myList = new ArrayList<>(100);
    }

    public boolean addItemToMyList(int item) {
        return this.myList.add(item);
    }

    public boolean removeItemFromMyList(Integer item)
    {
        return this.myList.remove(item);
    }

    public boolean removeItemFromMyList(int item)
    {
        return this.removeItemFromMyList(Integer.valueOf(item));
    }

    public void printMyListItems() {
        System.out.println("Elemente in der Liste:");
        for (Integer string : myList) {
            System.out.println(string);
        }
    }
}