// Ausgangspunkt:

//  class NoBinaryNumberException extends RuntimeException{
// 	private String bin;
// 	private int position;
//         void setBin(String bin){
//             this.bin=bin;
//         }
//         String getBin(){
//             return bin;
//         }
//         void setPosition(int position){
//             this.position=position;
//         }
//         int getPosition(){
//             return position;
//         }
        
        
// 	NoBinaryNumberException(){
// 		super();
// 	}
	
// 	NoBinaryNumberException(String s, int p){
//            super(s  + p );

// 		this.bin = s;
// 		this.position = p;
		
// 	}	
// }
// class ConvertBinary {

 
  
//         public static int  Binary(String st)throws NoBinaryNumberException {
  
      
//   for (int i = 0; i< st.length(); i++){
// 				char c = st.charAt(i);
// 				if(!(c == '0') && !(c == '1')){
// 					throw new NoBinaryNumberException(st, i+1);
// 				}
         
//         }
 
//  int n = Integer.parseInt(st);
//         int num = n; 
//         int dec_value = 0; 
  
//         int base = 1; 
  
//         int temp = num; 
//         while (temp > 0) { 
//             int last_digit = temp % 10; 
//             temp = temp / 10; 
  
//             dec_value += last_digit * base; 
  
//             base = base * 2; 
//         } 
  
        
        
  
//         return dec_value; 
        
//     } 
// }
  


// class ConvertBinaryTest{
  
//     public static void main(String[]args){
   
//  int s;
//    try{
      
//        s=ConvertBinary.Binary("11511");
//        System.out.println("Die Dezimale Zahl ist "+ s);
       
//    }
//    catch (NoBinaryNumberException e){
       
//       System.out.println("Das eingegebene Zahl: "+e.getBin()+" Format entspricht nicht den Richtlinien. an der Position: "+e.getPosition());
//     }
    
    
//     }
// }
