public class ConvertBinary {
    public static int Binary(String binaryNumberString) throws NoBinaryNumberException {
        // 1101
        if (binaryNumberString == null)
        {
            throw new NoBinaryNumberException("Die uebergebene Zahl ist null! Umwandlung nicht moeglich.");
        }

        for (int i = 0; i< binaryNumberString.length(); i++){
            char c = binaryNumberString.charAt(i);
            if(!(c == '0') && !(c == '1')){
                throw new NoBinaryNumberException(binaryNumberString, i+1);
            }
        }

        int dec_value = 0; 
        // dec_value = 0

        int base = 1; 
        // base = 1

        // st = 1101
        int temp = Integer.parseInt(binaryNumberString);
        // temp = 1101

        // Solange temp > 0, durchlaufe die Schleife
        while (temp > 0) { 

            // last_digit bekommt die letzte Stelle der Zahl zugewiesen
            int last_digit = temp % 10; 
            
            // Wir werfen die letzte Stelle der Zahl weg
            temp = temp / 10; 

            // addiere folgendes zu dec_value: Wert der letzten Stelle (last_digit) * Wert von base
            dec_value += last_digit * base; 

            // Multipliziere base mit 2
            base = base * 2; 
        } 

        // 1. Schleifendurchlauf:
        // temp = 1101
        // base = 1
        // dec_value = 0
        // 31: last_digit = 1101 % 10 = 1
        // 34: temp = 1101 / 10 = 110
        // 37: dec_value = 0 + (1 * 1) = 1
        // 40: base = 1 * 2 = 2
        // 2. Schleifendurchlauf (temp > 0?) --> ja
        // temp = 110
        // base = 2
        // dec_value = 1
        // 31: last_digit = 110 % 10 = 0
        // 34: temp = 110 / 10 = 11
        // 37: dec_value = 1 + (0 * 2) = 1
        // 40: base = 2 * 2 = 4
        // 3. Schleifendurchlauf (temp > 0?) --> ja (11)
        // temp = 11
        // base = 4
        // dec_value = 1
        // 31: last_digit = 11 % 10 = 1
        // 34: temp = 11 / 10 = 1
        // 37: dec_value = 1 + (1 * 4) = 5
        // 40: base = 4 * 2 = 8
        // 4. Schleifendurchlauf (temp > 0?) --> ja (1)
        // temp = 1
        // base = 8
        // dec_value = 5
        // 31: last_digit = 1 % 10 = 1
        // 34: temp = 1 / 10 = 0
        // 37: dec_value = 5 + (1 * 8) = 13
        // 40: base = 8 * 2 = 16
        // 5. Schleifendurchlauf (temp > 0?) --> nein (0)
        // --> Kein Schleifendurchlauf mehr
        
        // Gib dec_value (13) zurück
        return dec_value; 
    } 
}