public class NoBinaryNumberException extends RuntimeException{
        
    NoBinaryNumberException() {
        super();
    }
    
    NoBinaryNumberException(String message) {
        super(message);
    }

    NoBinaryNumberException(String s, int p){
        super("Das eingegebene Zahl: " + s + " Format entspricht nicht den Richtlinien. an der Position: " + p);
    }
}