/*
Erzeugen Sie eine neue Exception NoBinaryNumberException, die von der Klasse RuntimeException abgeleitet ist. 
Sie soll neben den beiden Standardkonstruktoren einen weiteren Konstruktor besitzen, 
der einen String (eine Binärzahl in der Form "10001110") sowie die Position, die die Exception ausgelöst hat, entgegennimmt.

Schreiben Sie eine Klasse ConvertBinary, 
die eine im String-Format übergebene Binärzahl in einen int-Typ umwandelt. 
Wird keine korrekte Zahl zur Umwandlung übergeben, soll eine Exception vom Typ NoBinaryNumberException ausgelöst werden.

Schreiben Sie eine Klasse ConvertBinaryTest zum Testen der Umwandlung.
*/

public class ConvertBinaryTest{
  
    public static void main(String[]args){
        
        if (args.length != 1)
        {
            System.out.println("Es muss genau ein Startparameter angegeben werden! Das Programm bricht hier ab.");
            return;
        }
        
        if (args[0].length() == 0)
        {
            System.out.println("Der Wert muss mindestens 1 Zeichen lang sein! Das Programm bricht hier ab.");
            return;
        }

        // Dieser Fehlerfall wird aber auch von ConvertBinary.Binary abgefangen
        if (args[0].startsWith("-"))
        {
            System.out.println("Negative Werte sind nicht erlaubt! Das Programm bricht hier ab.");
            return;
        }

        try{
            //int s=ConvertBinary.Binary(args[0]);
            int s=ConvertBinary.Binary(null);
            System.out.println("Die Dezimale Zahl ist "+ s);
        }
        catch (NoBinaryNumberException e){
            System.out.println(e.getMessage());
        }
    }
}
