public class Car {
    private String brand;

    /**
     * @return the brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * @param brand the brand to set
     */
    public void setBrand(String brand) {
        // Validierung!
        this.brand = brand;
    }

    public Car(String brand) {
        this.setBrand(brand);
    }

    public Car() {
        this.setBrand("Tesla");
    }

    public String toString() {
        return "Ich bin ein Auto der Marke " + this.getBrand();
    }

    public boolean equals(Object obj) {
        if (this == obj) 
        {
            return true; // Es ist dasselbe Objekt
        }

        if (obj == null) {
            return false; // Null-Referenz
        }

        if (obj.getClass() != this.getClass()) {
            return false; // Unterschiedlicher Datentyp
        }
        
        // Vergleich aller Attribute
        Car carObj = (Car)obj;

        if (!this.getBrand().equals(carObj.getBrand()))
        {
            return false;
        }

        return true;
    }

    public int hashCode() {
        int hc = 17; // willkürlicher Anfangswert
        int multiplikator = 59; // nicht zu große Primzahl
        
        // hc = hc + multiplikator*hashAttribut1 + multiplikator*hashAttribut2 + …
        hc = hc + multiplikator * this.getBrand().hashCode();
        
        return hc;
    }
}