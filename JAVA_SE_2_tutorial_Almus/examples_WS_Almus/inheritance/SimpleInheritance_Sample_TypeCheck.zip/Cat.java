/**
 * Cat
 */
public class Cat extends Animal {
    private String eyeColor;

    public String getEyeColor() {
        return eyeColor;
    }

    public void setEyeColor(String eyeColor) {
        this.eyeColor = eyeColor;
    }

    public Cat() {
        // Constructor chaining
        // --> call the dog constructor with parameters
        // reduces the need to validate values multiple times
        this(0, "White");
        System.out.println("Cat default constructor called");
    }


    public Cat(int age, String eyeColor) {
        // call the super class constructor
        // reduces the need to validate input multiple times
        super(age, 4);

        // Validate eyeColor (and only eyeColor, since age and leg number is validated in super class)
        if (eyeColor.length() == 0)
        {
            System.out.println("FEHLER !!! Augenfarbe darf nicht leer sein");
        }
        
        this.eyeColor = eyeColor;
        System.out.println("Cat constructor called: " + this.eyeColor);
    }

    public void Meows()
    {
        System.out.println("Miau Miau");
    }
}