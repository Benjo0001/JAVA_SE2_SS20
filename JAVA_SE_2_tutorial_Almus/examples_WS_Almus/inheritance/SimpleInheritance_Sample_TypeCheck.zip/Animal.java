public class Animal {

    private int age;
    private int numberOfLegs;

    public int getAge() {
        return age;
    }

    public int getNumberOfLegs() {
        return numberOfLegs;
    }

    public void setNumberOfLegs(int numberOfLegs) {
        this.numberOfLegs = numberOfLegs;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Animal() {
        // Constructor chaining
        // --> call the animal constructor with parameters
        // reduces the need to validate values multiple times
        this(0, 3);
        System.out.println("Animal default constructor called");
    }

    public Animal(int age, int numberOflegs) {
        
        // Validate age
        if (age < 0)
        {
            System.out.println("FEHLER!!!! Alter muss groesser 0 sein!");
        }

        // Validate numberOfLegs
        if (numberOflegs < 1)
        {
            System.out.println("FEHLER!!! Tier muss mindestens 1 Bein haben!!!");
        }

        this.age = age;
        this.numberOfLegs = numberOflegs;
        System.out.println("Animal constructor called: " + this.age + " " + this.numberOfLegs);
    }
}