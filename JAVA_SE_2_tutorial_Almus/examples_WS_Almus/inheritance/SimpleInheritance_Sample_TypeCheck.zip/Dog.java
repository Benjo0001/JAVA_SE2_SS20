/**
 * Dog
 */
public class Dog extends Animal {
    private String race;

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }
    
    public Dog() {
        // Constructor chaining
        // --> call the dog constructor with parameters
        // reduces the need to validate values multiple times
        this(0, "Hunderasse");
        System.out.println("Dog default constructor called");
    }

    public Dog(int age, String race) {
        // call the super class constructor
        // reduces the need to validate input multiple times
        super(age, 4);

        // Validate race (and only race, since age and leg number is validated in super class)
        if (race.length() == 0)
        {
            System.out.println("FEHLER !!! Hunderasse darf nicht leer sein");
        }

        this.race = race;
        System.out.println("Dog constructor called: " + this.race);
    }

    public void Bark()
    {
        System.out.println("Wuff Wuff");
    }
}