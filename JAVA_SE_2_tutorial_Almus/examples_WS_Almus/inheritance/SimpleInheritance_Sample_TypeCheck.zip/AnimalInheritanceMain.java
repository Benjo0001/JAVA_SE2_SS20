/**
 * AnimalInheritanceMain
 */
public class AnimalInheritanceMain {

    public static void CallAnimalSound(Dog dog)
    {
        dog.Bark();
    }

    public static void CallAnimalSound(Cat cat)
    {
        cat.Meows();
    }

    public static void CallAnimalSound2(Object animal)
    {
        // At this point we DO NOT know, what type we got (is it a Cat? Is it a Dog?)
        // So me need to check the type!
        if (animal instanceof Dog)
        {
            ((Dog)animal).Bark();
        }

        if (animal instanceof Cat)
        {
            ((Cat)animal).Meows();
        }
    }

    public static void main(String[] args) {
        
        // Instanciate cat and dog
        Dog bello = new Dog(1, "Dogge");
        Cat miez = new Cat(2, "Gelbgruen gestreift");

        // simple demo of instanceof (at this point it is clear what type we got)
        if (bello instanceof Dog)
        {
            System.out.println("Bello ist ein Hund");
        }

        if (miez instanceof Cat)
        {
            System.out.println("Miez ist eine Katze");
        }

        // Call to specific method (one for dog, one for cat)
        // CallAnimalSound(bello);
        // CallAnimalSound(miez);
        
        // Call to unspecific method (one for both dog AND cat)
        CallAnimalSound2(bello);
        CallAnimalSound2(miez);

        // The expected output:
        // Animal constructor called: 1 4
        // Dog constructor called: Dogge
        // Animal constructor called: 2 4
        // Cat constructor called: Gelbgrün gestreift
        // Bello ist ein Hund
        // Miez ist eine Katze
        // Wuff Wuff
        // Miau Miau
    }
}